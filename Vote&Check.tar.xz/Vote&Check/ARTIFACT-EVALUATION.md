# Artifact Appendix

Paper title: **Vote&Check: Secure Postal Voting with Reduced Trust Assumptions**

Artifacts HotCRP Id: **8** (not your paper Id, but the artifacts id)

Requested Badge: **Reproduced**

## Description
This files are the models we used to prove the safety of our protocol.

### Security/Privacy Issues and Ethical Concerns (All badges)
None

## Basic Requirements (Only for Functional and Reproduced badges)
Our experiments were run on a standard laptop equipped with a 4-core Intel i7-8665U CPU, with 16 GB of RAM, and last less than a minute.

### Hardware Requirements
None

### Software Requirements
We used the commit cc4f8cde5 of the improved_scope_lemma branch of the ProVerif tool.

### Estimated Time and Storage Consumption
Each individual run of ProVerif takes about one minute or less (see Figure 5 of the article). Some of the scripts launch up to 8 corruption scenarios, so the running time for them can be a few minutes.

No significant storage is required.

## Environment 
In the following, describe how to access our artifact and all related and necessary data and software components.
Afterward, describe how to set up everything and how to verify that everything is set up correctly.

### Accessibility (All badges)
Artifacts are available at https://inria.hal.science/hal-04813613v2


### Set up the environment (Only for Functional and Reproduced badges)

To install proverif, run the following commands:

```
sudo apt-get install curl gcc make git
sudo bash -c "sh <(curl -fsSL https://opam.ocaml.org/install.sh)"
opam init
```
Note: choose "y" and "1"

```
opam install proverif
```
Note: it should propose you to use apt-get to install external dependencies. Do so. If needed, run sudo apt-get update and retry

```
eval $(opam env)
git clone https://gitlab.inria.fr/bblanche/proverif.git
cd proverif/
git checkout cc4f8cde5d6e9c0901564de93e12e2133eeb2bf4
cd proverif/
./build
pwd
PATH="current-path-displayed-at-11":$PATH
```

Two errors are raised and should be ignored:
cp: cannot stat 'analyze': No such file or directory
cp: cannot stat 'addexpectedtags': No such file or directory

### Testing the Environment (Only for Functional and Reproduced badges)
Simply run the following command:
```
proverif
```
It should return no result (and no error).

## Artifact Evaluation (Only for Functional and Reproduced badges)

### Main Results and Claims

#### Main Result 1: Vote privacy

Vote&Check voting protocol preserves vote privacy under some hypothesis.

#### Main Result 2: Verifiability

Vote&Check also provides verifiability under other hypothesis.

### Experiments 
List each experiment the reviewer has to execute. Describe:
 - How to execute it in detailed steps.
 - What the expected result is.
 - How long it takes and how much space it consumes on disk. (approximately)
 - Which claim and results does it support, and how.

#### Full Experiment

The command `./make_figure.sh` runs all experiments at once and reproduces the figure 5 of the paper.

It is also possible to verify the properties one by one.


#### Experiment 1: Privacy

##### How to automatically run? 

The command ./script_privacy runs the experiment in all corruption scenarios.

##### How to manually run? 

To run a privacy experiment:
- First, set up the threat model in privacy.pv, lines 322-324. The three statuses can be set either to `honest` or to `corrupt`.
- The voter model should also be specified on line 13. 
- Then, run the following command: `proverif privacy.pv`
The result is `true` means that the privacy property holds in the chosen threat model, and `cannot be proved` or `false` otherwise.


#### Experiment 2: Verifiability

The verifiability experiments builds on the framework developed by Cortier et. al. 
Therefore, verification is not as simple as running one simple ProVerif command. 
Instead, proof must proceed in two step:
- 1 - prove lemmas
- 2 - prove the main queries

Moreover, the complexity of the model requires to fine-tune the internal proof strategy of ProVerif by using advanced features of the tool. Unfortunately, ProVerif interface does not allow to setup different options for different lemmas/queries included in a single ProVerif file. When necessary we thus split them in several files. 

##### How to automatically run? 
The following commands run the experiments in all relevant corruption scenarios:
- `./script_properties1`
- `./script_properties2` 
- `./script_indiv`
- `./script_weak_universal`
- `./script_universal`

##### How to manually run? 
For sake of simplicity, we defined a MAKEFILE which contains one target per ProVerif command. 
To run a verifiability experiment:
- First, define the corruption scenario in protocol.pvl: the status of the tracker server, the printer, and the election office can be set to `honest` or `corrupt` on lines 7-9.
- Then, run the following commands:
  + -1- prove lemmas:
    * `make prop1`
    * `make prop2` 
  + -2- prove the main queries
    * `make indiv`
    * `make weak`
    * `make univ`


##### TARGET FILES

- `prop1.pv` proves intermediate lemmas:
Lemma_Common Lemma_Cell_BB and Lemma_Final_Tally_Voter are defined in the voting framework.
Lemma_new_lemma contains lemmas that we used in the appendix to prove our axiom.
All lemmas are proved true, and the dummy query is proved false.

- `prop2.pv` proves the rest of the intermediate lemmas, using the previously proved ones as axioms.
All lemmas are proved true, and the dummy query is proved false.

- `indiv.pv`, `weak_universal.pv`, and `universal.pv` prove our main queries, i.e. respectively the individual verifiability, weak universal verifiability, and universal verifiability.
The result is `true` if the property holds in this threat model and `cannot be proved` or `false` in the other case.

In order to verify our main security properties, i.e. *E2E verifiability* and *weak verifiability*, one should thus verify the queries in `make indiv` and, respectively, `make univ` or `make weak`.
Of course, lemmas present in `prop1.pv` and `prop2.pv` must be proved first. 


##### LIBRARIES

Our ProVerif model is split in several files. 
The one containing the query to prove is `xxx.pv` and several *libraries* named `xxx.pvl`. 

List of libraries: 
- `framework/gsverif_library.pvl` contains generic lemmas and models counters.
- `framework/voting_framework.pvl` models a generic voting process.
- `framework/properties.pvl` contains all the framework lemmas plus our new lemmas. 
- `protocol.pvl` contains our model of Vote&Check.

**Remark:** In `framework/properties.pvl` lemmas are grouped in *macro* commands that can then be expanded in the `xxx.pv` file when necessary. For sake of simplicity, each lemma (and group of lemmas) is accompanied by its *axiom* version (i.e. the same version that ProVerif will expand as an axiom instead of as a lemma). 
During our verifications, we first expand the *lemma* version to let ProVerif prove its validity. Then, in the following proofs (e.g. when proving the main properties) we expand the *axiom* version to make ProVerif leverage it without proving it again (it's been proved before).   
A better ProVerif user interface could avoid the need of such duplications of code. 

##### SANITY CHECK

We check that our model is executable, i.e. that all the hypotheses that occur in premise of a query are reachable. 
Unfortunately, ProVerif is not well-suited to conduct such "exist-trace" queries. Therefore, to ease the verification, we first limit the analysis, via restrictions, to scenarios where there are only two conscientious voters. If our events are reachable in such restricted scenarios, then they are in more general ones, without the extra restrictions, too. 
In our model this trick is not enough to make ProVerif prove the reachability of these events. Indeed, the complexity of the function `get_ident_from_ballot()` which contains many if/get-then-else commands leads to an exponential blow-up during verification, and prevent ProVerif from terminating in *reasonable* time. 
Fortunately, the model can be manually simplified to remove traces to be explored and thus ease the verification: reader can comment the lines 244-247 from protocol.pvl.  
This is done automatically in `./script_sanity`.


## Limitations (Only for Functional and Reproduced badges)
None (all our results are proven here)
