#!/bin/bash

cd privacy
echo "Running privacy script..."
./script_privacy

cd ../verifiability
echo "Running prop1 script..."
./script_properties1
echo "Running prop2 script..."
./script_properties2
echo "Running indiv verif script..."
./script_indiv
echo "Running univ verif script..."
./script_universal
echo "Running weak univ verif script..."
./script_weak_universal

privdir=`ls -rtd /tmp/privacy_run.* | tail -1`
prop1dir=`ls -rtd /tmp/prop1_run.* | tail -1`
prop2dir=`ls -rtd /tmp/prop2_run.* | tail -1`
univdir=`ls -rtd /tmp/univ_run.* | tail -1`
weakdir=`ls -rtd /tmp/weak_run.* | tail -1`
indivdir=`ls -rtd /tmp/indiv_run.* | tail -1`

echo "scenario                priv-off  priv-onl  prop1     prop2     univ      weak      indiv"
echo "-----------------------------------------------------------------------------------------"


for scenario in honest.honest.honest corrupt.honest.honest honest.corrupt.honest honest.honest.corrupt honest.corrupt.corrupt corrupt.honest.corrupt corrupt.corrupt.honest corrupt.corrupt.corrupt; do

echo -n "$scenario	"

# col 1
file=$privdir/${scenario}.true/out
res=`grep RESULT $file`
if [ "$res" = "RESULT Diff-equivalence is true." ]; then echo -n true; else echo -n XXXX; fi
echo -n "      "
t=`grep "^user" $file | cut -f 2`
timeline="$t  "

# col 2
file=$privdir/${scenario}.false/out
res=`grep RESULT $file`
if [ "$res" = "RESULT Diff-equivalence is true." ]; then echo -n true; else echo -n XXXX; fi
echo -n "      "
t=`grep "^user" $file | cut -f 2`
timeline="${timeline}$t  "

# col 3a
file=$prop1dir/${scenario}/out
check_false=`grep "^RESULT .* is false.$" $file | wc -l`
check_true=`grep "^RESULT .* is true.$" $file | wc -l`
if [ "$check_false" = "1" -a "$check_true" = "34" ]; then echo -n true; else echo -n XXXX; fi
echo -n "      "
t=`grep "^user" $file | cut -f 2`
timeline="${timeline}$t  "

# col 3b
file=$prop2dir/${scenario}/out
check_false=`grep "^RESULT .* is false.$" $file | wc -l`
check_true=`grep "^RESULT .* is true.$" $file | wc -l`
if [ "$check_false" = "1" -a "$check_true" = "2" ]; then echo -n true; else echo -n XXXX; fi
echo -n "      "
t=`grep "^user" $file | cut -f 2`
timeline="${timeline}$t  "

# col 4
file=$univdir/${scenario}/out
if [ -f $file ]; then
      check_true=`grep "^RESULT .* is true.$" $file | wc -l`
      if [ "$check_true" = "1" ]; then echo -n true; else echo -n XXXX; fi
      t=`grep "^user" $file | cut -f 2`
      timeline="${timeline}$t "
else
      echo -n XXXX;
      timeline="${timeline}-------  "
fi
echo -n "      "

# col 5
file=$weakdir/${scenario}/out
if [ -f $file ]; then
      check_true=`grep "^RESULT .* is true.$" $file | wc -l`
      if [ "$check_true" = "1" ]; then echo -n true; else echo -n XXXX; fi
      t=`grep "^user" $file | cut -f 2`
      timeline="${timeline}$t "
else
      echo -n XXXX;
      timeline="${timeline}------- "
fi
echo -n "      "

# col 6
file=$indivdir/${scenario}/out
if [ -f $file ]; then
      check_true=`grep "^RESULT .* is true.$" $file | wc -l`
      if [ "$check_true" = "1" ]; then echo -n true; else echo -n XXXX; fi
      t=`grep "^user" $file | cut -f 2`
      timeline="${timeline}$t "
else
      echo -n XXXX;
      timeline="${timeline}------- "
fi
echo 

echo -n "                        "
echo $timeline
echo

done
