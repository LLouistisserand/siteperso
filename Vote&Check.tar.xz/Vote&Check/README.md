# Vote&Check: Secure Postal Voting with Reduced Trust Assumptions


This repository contains the ProVerif files required to reproduce the results of Section 4 of the article "Vote&Check: Secure Postal Voting with Reduced Trust Assumptions", by Véronique Cortier, Alexandre Debant, Pierrick Gaudry, and Léo Louistisserand.

For the verifiability part, we use the framework from [A], which uses features of ProVerif that have not yet been merged to the main branch.  Therefore, for the following, it is necessary to use the commit cc4f8cde5 from the improved_scope_lemma branch of ProVerif, available at 
  https://gitlab.inria.fr/bblanche/proverif/-/tree/improved_scope_lemma

To install the software, one should run the following commands:

    sudo apt-get install curl gcc make git
    sudo bash -c "sh <(curl -fsSL https://opam.ocaml.org/install.sh)"
    opam init
		Note: choose "y" and "1"
	opam install proverif
		Note: it should propose you to use apt-get to install external dependencies. Do so. If needed, run sudo apt-get update and retry
	eval $(opam env)
	git clone https://gitlab.inria.fr/bblanche/proverif.git
	cd proverif/
	git checkout cc4f8cde5d6e9c0901564de93e12e2133eeb2bf4
	cd proverif/
	./build
	pwd
	PATH="current-path-displayed-at-11":$PATH

Two errors are raised and should be ignored:
cp: cannot stat 'analyze': No such file or directory
cp: cannot stat 'addexpectedtags': No such file or directory

[A] Véronique Cortier, Alexandre Debant, and Vincent Cheval. 2023. Election Verifiability with ProVerif. In CSF. IEEE


The files are separated into two subdirectories, one for privacy, one for verifiability.


# PRIVACY PART

### How to automatically run?
The command ./script_privacy runs the experiment in all corruption scenarios.

### How to manually run?
To run the privacy experiments:
- First, set up the threat model in privacy.pv, lines 322-324. The three statuses can be set either to `honest` or to `corrupt`.
- The voter model should also be specified on line 13. 
- Then, run the following command: `proverif privacy.pv`
The result is `true` means that the privacy property holds in the chosen threat model, and `cannot be proved` or `false` otherwise.

**Remark:** When proving equivalence queries in presence of restrictions, ProVerif does not check observational equivalence. Instead it proves diff-equivalence. Therefore, even if ProVerif returns `false` then the user must manually check the validity of the returned attack trace. 
In the absence of restrictions, ProVerif check observational equivalence, but will never return `false`. A manual check must still check the validity of the returned attack trace in case of `cannot be proved`.


# VERIFIABILITY PART

The verifiability experiments build on the framework developed by Cortier et. al. [A]. 
Therefore, verification is not as simple as running one simple ProVerif command. 
Instead, proof must proceed in two step:
- 1 - prove lemmas
- 2 - prove the main queries

Moreover, the complexity of the model requires to fine-tune the internal proof strategy of ProVerif by using advanced features of the tool. Unfortunately, ProVerif interface does not allow to setup different options for different lemmas/queries included in a single ProVerif file. When necessary we thus split them in several files. 

### How to automatically run?

The following commands run the experiments in all relevant corruption scenarios:
- `./script_properties1`
- `./script_properties2` 
- `./script_indiv`
- `./script_weak_universal`
- `./script_universal`


### TARGET FILES

- `prop1.pv` proves intermediate lemmas:
Lemma_Common Lemma_Cell_BB and Lemma_Final_Tally_Voter are defined in the voting framework.
Lemma_new_lemma contains lemmas that we used in the appendix to prove our axiom.
All lemmas are proved true, and the dummy query is proved false.

- `prop2.pv` proves the rest of the intermediate lemmas, using the previously proved ones as axioms.
All lemmas are proved true, and the dummy query is proved false.

- `indiv.pv`, `weak_universal.pv`, and `universal.pv` prove our main queries, i.e. respectively the individual verifiability, weak universal verifiability, and universal verifiability.
The result is `true` if the property holds in this threat model and `cannot be proved` or `false` in the other case.

In order to verify our main security properties, i.e. *E2E verifiability* and *weak verifiability*, one should thus verify the queries in `./script_indiv` and, respectively, `./script_universal` or `./script_weak_universal`.
Of course, lemmas present in `prop1.pv` and `prop2.pv` must be proved first. 


### How to manually run?
For sake of simplicity, we defined a MAKEFILE which contains one target per ProVerif command. 
To run the verifiability experiments:
- First, define the corruption scenario in protocol.pvl: the status of the tracker server, the printer, and the election office can be set to `honest` or `corrupt` on lines 7-9.
- Then, run the following commands:
  + -1- prove lemmas:
	* `make prop1`
	* `make prop2` 
  + -2- prove the main queries
	* `make indiv`
	* `make weak`
	* `make univ`

### LIBRARIES

Our ProVerif model is split in several files. 
The one containing the query to prove is `xxx.pv` and several *libraries* named `xxx.pvl`. 

List of libraries: 
- `framework/gsverif_library.pvl` contains generic lemmas and models counters.
- `framework/voting_framework.pvl` models a generic voting process.
- `framework/properties.pvl` contains all the framework lemmas plus our new lemmas. 
- `protocol.pvl` contains our model of Vote&Check.

**Remark:** In `framework/properties.pvl` lemmas are grouped in *macro* commands that can then be expanded in the `xxx.pv` file when necessary. For sake of simplicity, each lemma (and group of lemmas) is accompanied by its *axiom* version (i.e. the same version that ProVerif will expand as an axiom instead of as a lemma). 
During our verifications, we first expand the *lemma* version to let ProVerif prove its validity. Then, in the following proofs (e.g. when proving the main properties) we expand the *axiom* version to make ProVerif leverage it without proving it again (it's been proved before).   
A better ProVerif user interface could avoid the need of such duplications of code. 


### SANITY CHECK

We check that our model is executable, i.e. that all the hypotheses that occur in premise of a query are reachable. 
Unfortunately, ProVerif is not well-suited to conduct such "exist-trace" queries. Therefore, to ease the verification, we first limit the analysis, via restrictions, to scenarios where there are only two conscientious voters. If our events are reachable in such restricted scenarios, then they are in more general ones, without the extra restrictions, too. 
In our model this trick is not enough to make ProVerif prove the reachability of these events. Indeed, the complexity of the function `get_ident_from_ballot()` which contains many if/get-then-else commands leads to an exponential blow-up during verification, and prevent ProVerif from terminating in *reasonable* time. 
Fortunately, the model can be manually simplified to remove traces to be explored and thus ease the verification: reader can comment the lines 244-247 from protocol.pvl.  
This is done automatically in `./script_sanity`.


# REPRODUCING THE FIGURE

A scripts runs all experiments and reproduces the figure 5. The command ./make_figure.sh runs this script.


# Appendix B - instantiation of the axiom 

Appendix B.4 defines 4 queries that must be satisfied to justify the use of an axiom which prevents ProVerif from over-approximating else branches. 
These lemmas are defined in `framework/properties.pvl` in the macro `Lemma_new_lemma()`. Once proved, the corresponding axioms are defined in the macro `Proved_new_lemma()`. Finally, the main axiom whose soundness is proved in Propostion B.1 is defined in the macro `No_fail_axiom()`. 

Because lemmas/axiom must be fine-tuned according to the honesty of the agents, `Lemma_new_lemma()` contains several versions of the lemmas defined in Appendix B.4. 
Each lemma/axiom (except the one corresponding to $\rho_2$) is parametrized by 1 or 2 events that define in which scenarios they can be applied. These events `Printer_status(.)` and `Trackerserver_status(.)` simply define the honesty of the authorities and are executed at the very beginning of the main process. They do not interfere with the soundness Proposition B.1. 

The lemmas/axiom deal with a table. In our ProVerif model, this table is `public_identifier` and contains data generated in the framework during the registration of voter. Each insertion is preceded by an event `Public_identifier(.)` to record it.  
Positive lookups, i.e. `getSucc(.,.)` are identified by the event `Read_table_public_identifier(.)` which is triggered each time a `get` on the table `public_identifier` is executed.   
Negative lookups, i.e `getFail(.,.)` are identified by the event `Fail_X(.)`. However, because the test $D$ varies depending on the honesty of the authorities, we define three different events, i.e. $X \in \{c,t,n\}$. 

Finally, because the axiom is used to improve ProVerif accuracy in the `get_ident_from_ballot()` function, we define an event `Enter_GIFB_X(.)` which contains the *authentication factor* used to identify the voter. Since this depends on the honesty of the authorities (it is either $c$, $t$, or $n$ ), we define three different events, i.e. $X \in \{c,t,n\}$.

We explain here how to instantiate the queries/axiom defined in Appendix B.4. 
Authorities honesty events are omitted as explained above.

**Query $\rho_1$:** 
- $F_1$ ==> `Enter_GIFB_X(.)`
- $F_2$ ==> `Public_identifier(.)`
- $p-getSucc(.)$ ==> `Read_table_public_identifier(.)`

**Query $\rho_2$:** 
- $p-getSucc(.)$ ==> `Read_table_public_identifier(.)`
- $D$ ==> the data has the right form.   
Note: our test covers the 3 different tests performed in `get` commands depending on the honesty of the authorities (i.e. whether the authentication factor is $c$, $t$, or $n$)

**Query $\rho_3$:** 
- $F_1$ ==> `Enter_GIFB_X(.)`
- $F_2$ ==> `Public_identifier(.)`

**Query $\rho_4$:**
- $F_1$ ==> `Enter_GIFB_X(.)`
- $F_2$ ==> omitted; it makes the query stronger and thus preserves the soundness of our Proposition B.1
- $p-getFail()$ ==> `Fail_X`

**Query $ax$:**
- $F_1$ ==> `Enter_GIFB_X(.)`
- $F_2$ ==> `Public_identifier(.)`
- $p-getFail()$ ==> `Fail_X`
